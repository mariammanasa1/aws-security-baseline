# Prowler reports

Unzip your two Prowler downloads here:

- `prowler-baseline.zip` → the scan **before** remediation
- `prowler-after.zip` → the scan **after** enabling CloudTrail

Each contains HTML (open in a browser for a clickable report), CSV, JSON (OCSF),
and per-framework compliance CSVs. Open the `.html` files to explore every
finding with its severity, remediation guidance, and the affected resource.
