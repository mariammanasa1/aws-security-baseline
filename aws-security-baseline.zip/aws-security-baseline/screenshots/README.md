# Screenshots

Add these:

- `01-prowler-baseline.png` — the Prowler "Overview Results" summary **before** remediation (28 passed / 74 failed, CIS 38.9%).
- `02-prowler-after.png` — the Prowler summary **after** enabling CloudTrail (84 passed / 65 failed, CIS 67.3%).
- `03-cloudtrail-trail.png` — the CloudTrail Trails page showing your multi-region `management-events` trail.

The first two side by side are the proof of the before/after improvement.
